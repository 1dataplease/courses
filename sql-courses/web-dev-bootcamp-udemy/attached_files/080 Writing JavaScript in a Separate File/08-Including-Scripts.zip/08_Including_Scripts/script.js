var firstName = prompt("What is your first name?");
var lastName = prompt("What is your last name?");
var age = prompt("How old are you?");

console.log("Your full name is " + firstName + " " + lastName);
console.log("You are " + age + " years old");


// var x = prompt("Give me the first number")
// var y = prompt("Give me the second number")
// var result = Number(x) + Number(y);
// console.log(result)